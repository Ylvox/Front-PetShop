export default function detalhes({ dados }) {

    return (
        <div className="container">
            <div className="row">
                <div className="col-4 text-center">
                    <img src={dados.imagem} className="img-fluid rounded shadow" alt={dados.nome}></img>
                </div>
                <div className="col-8 text-center">
                    <h3>{dados.nome}</h3>
                    <p>Categoria: {dados.categoria}</p>
                    <p>Nota: {dados.nota} de 5</p>
                    <p>Total: R$ {dados.total}</p>
                    <h6>Descrição:</h6>
                    <p className='sinopse m-auto mb-4'>{dados.descricao}</p>
                    <button className="btn btn-success">Adicionar ao carrinho</button>
                </div>
            </div>
        </div>
    );

}