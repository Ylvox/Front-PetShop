import { Link } from 'react-router-dom';

export default function form({ tipo }) {
    return (
        <>
            {(() => {
                if(tipo = "login"){
                    return(
                        <div className="container">
                            <div className="row">
                                <div className="col-12 text-center my-4 text-muted">
                                    <h4>Login Cliente</h4>
                                </div>
                                <hr></hr>
                                <div className="col-lg-5 col-md-12"></div>
                                <div className="my-2 col-lg-2 col-md-12">
                                    <form>
                                        <div className="mb-3">
                                        <input type="email" class="form-control text-center" id="email" placeholder="Email"></input>
                                        </div>
                                        <div className="mb-3">
                                        <input type="password" class="form-control text-center" id="pwd" placeholder="Senha"></input>
                                        </div>
                                        <div className="mb-3 text-center d-grid">
                                            <Link to="/cadastrar" className='btn btn-primary'>Cadastre-se aqui</Link>
                                        </div>
                                        <div className='mb-3 text-center d-grid'>
                                        <input type='submit' className='btn btn-success' value="Logar"></input>
                                        </div>
                                    </form>
                                </div>
                                <div className="col-lg-5 col-md-12"></div>
                            </div>
                        </div>
                    );
                }
            })()}
        </>
    );
}