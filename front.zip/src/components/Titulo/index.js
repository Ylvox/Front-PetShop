export default function Titulo({title, text, tipo}) {
    if(tipo == "detalhes"){
        return(
            <div className="Titulo mt-5">
                <div className="container text-center">
                    <h1>{title} - Detalhes</h1>
                    <hr></hr>
                </div>
            </div>
        );
    }else{
        return (
            <div className="Titulo mt-5">
                <div className="container text-center">
                    <h1>{title}</h1>
                    <p className="text-muted">{text}</p>
                    <hr></hr>
                </div>
            </div>
        );
    }
}