import Menu from '../components/Menu/index';

export default function home(){
    return(
        <>
            <Menu menu='home-produto'/>
        </>
    );
}