import Detalhes from '../components/Detalhes/index';
import Menu from '../components/Menu/index';
import Titulo from '../components/Titulo';
import { useParams } from 'react-router-dom';

//APENAS EXEMPLO
const produto =
{
    "produtoId": 10,
    "nome": "Casinha de cachorro",
    "categoria": "lazer",
    "nota": 4.3,
    "total": 129.89,
    "descricao": "Casinha para cachorro media, protege contra chuva e é quentinha.",
    "imagem": "https://images.tcdn.com.br/img/img_prod/601564/casinha_madeira_no_06_6_1_20171212145832.jpg"
}

export default function DetalhesP() {

    const { id } = useParams();

    /* useEffect(() => {
        fetch('https://my-json-server.typicode.com/marycamila184/moviedetails/moviedetails/' + id) //link api
            .then(response => response.json())
            .then(data => setData(data))
            .catch(err => console.error(err))
    }, []);

    if (!data) {
        return (
            <div className="text-center m-auto col-12">
                <h4>Carregando...</h4>
            </div>
        );
    } */

    return (
        <>
            <Menu menu='home-produto' />
            <Titulo tipo='detalhes' title={produto.nome} />
            <div className="Detalhes mt-5">
                {(() => {
                    if (produto.produtoId == null) {
                        return (
                            <div className="text-center m-auto col-12">
                                <h4>Produto indisponivel</h4>
                            </div>
                        );
                    } else {
                        return (
                            <Detalhes dados={produto} />
                            //COLOCAR COMENTARIOS AQUI
                        );
                    }
                })()}
            </div>
        </>
    );
}